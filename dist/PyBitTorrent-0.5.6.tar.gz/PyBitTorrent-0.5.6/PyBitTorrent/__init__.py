# Expose the more specific use relevant classes
from PyBitTorrent.Bittorrent import TorrentClient
from PyBitTorrent.TorrentFile import TorrentFile
from PyBitTorrent.HTTPTracker import HTTPTracker
from PyBitTorrent.UDPTracker import UDPTracker